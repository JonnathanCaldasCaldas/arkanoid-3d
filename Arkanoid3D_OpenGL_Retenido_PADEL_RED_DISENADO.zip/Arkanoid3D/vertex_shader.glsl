#version 330 core                                                        // Versión GLSL para OpenGL 3.3 Core.

layout (location = 0) in vec3 aPosition;                                 // Recibe posición local desde el VBO.
layout (location = 1) in vec3 aNormal;                                   // Recibe normal local desde el VBO.

uniform mat4 uView;                                                      // Matriz de vista de la cámara.
uniform mat4 uProjection;                                                // Matriz de proyección perspectiva.
uniform vec3 uTranslation;                                               // Vector de traslación del objeto gráfico.
uniform vec3 uRotation;                                                  // Ángulos de rotación Euler del objeto gráfico.
uniform vec3 uScale;                                                     // Factores de escalamiento del objeto gráfico.
uniform int uUseAxisAngle;                                               // Indica si se usa rotación eje-ángulo.
uniform vec3 uAxis;                                                      // Eje de rotación para la esfera.
uniform float uAxisAngle;                                                // Ángulo de rotación para la esfera.

out vec3 vFragPos;                                                       // Envía posición mundial al fragment shader.
out vec3 vNormal;                                                        // Envía normal mundial al fragment shader.
out vec3 vLocalPos;                                                      // Envía posición local para calcular degradados por cara.
out vec3 vLocalNormal;                                                   // Envía normal local para decidir qué cara del bloque se está pintando.

mat4 translationMatrix(vec3 t) {                                         // Construye matriz de traslación.
    mat4 M = mat4(1.0);                                                  // Inicia matriz identidad.
    M[3] = vec4(t, 1.0);                                                 // Coloca traslación en la última columna.
    return M;                                                           // Devuelve matriz T.
}                                                                        // Fin de translationMatrix.

mat4 scaleMatrix(vec3 s) {                                               // Construye matriz de escalamiento.
    mat4 M = mat4(1.0);                                                  // Inicia matriz identidad.
    M[0][0] = s.x;                                                       // Escala en X.
    M[1][1] = s.y;                                                       // Escala en Y.
    M[2][2] = s.z;                                                       // Escala en Z.
    return M;                                                           // Devuelve matriz S.
}                                                                        // Fin de scaleMatrix.

mat4 rotateX(float a) {                                                  // Construye matriz de rotación en X.
    float c = cos(a);                                                    // Calcula coseno.
    float s = sin(a);                                                    // Calcula seno.
    return mat4(1.0,0.0,0.0,0.0, 0.0,c,s,0.0, 0.0,-s,c,0.0, 0.0,0.0,0.0,1.0); // Devuelve Rx en formato columna.
}                                                                        // Fin de rotateX.

mat4 rotateY(float a) {                                                  // Construye matriz de rotación en Y.
    float c = cos(a);                                                    // Calcula coseno.
    float s = sin(a);                                                    // Calcula seno.
    return mat4(c,0.0,-s,0.0, 0.0,1.0,0.0,0.0, s,0.0,c,0.0, 0.0,0.0,0.0,1.0); // Devuelve Ry en formato columna.
}                                                                        // Fin de rotateY.

mat4 rotateZ(float a) {                                                  // Construye matriz de rotación en Z.
    float c = cos(a);                                                    // Calcula coseno.
    float s = sin(a);                                                    // Calcula seno.
    return mat4(c,s,0.0,0.0, -s,c,0.0,0.0, 0.0,0.0,1.0,0.0, 0.0,0.0,0.0,1.0); // Devuelve Rz en formato columna.
}                                                                        // Fin de rotateZ.

mat4 axisAngleMatrix(vec3 axis, float angle) {                            // Construye matriz eje-ángulo para la esfera.
    vec3 a = normalize(axis);                                             // Normaliza eje.
    float c = cos(angle);                                                 // Calcula coseno.
    float s = sin(angle);                                                 // Calcula seno.
    float oc = 1.0 - c;                                                   // Calcula 1 - coseno.
    return mat4(oc*a.x*a.x+c,     oc*a.x*a.y+a.z*s, oc*a.x*a.z-a.y*s, 0.0, // Columna 0.
                oc*a.x*a.y-a.z*s, oc*a.y*a.y+c,     oc*a.y*a.z+a.x*s, 0.0, // Columna 1.
                oc*a.x*a.z+a.y*s, oc*a.y*a.z-a.x*s, oc*a.z*a.z+c,     0.0, // Columna 2.
                0.0,               0.0,               0.0,             1.0); // Columna 3.
}                                                                        // Fin de axisAngleMatrix.

void main() {                                                            // Inicio del vertex shader.
    mat4 T = translationMatrix(uTranslation);                             // Calcula traslación en el shader.
    mat4 S = scaleMatrix(uScale);                                         // Calcula escalamiento en el shader.
    mat4 R = rotateZ(uRotation.z) * rotateY(uRotation.y) * rotateX(uRotation.x); // Calcula rotación compuesta.
    if (uUseAxisAngle == 1) R = axisAngleMatrix(uAxis, uAxisAngle);        // La esfera usa rotación en dirección de trayectoria.
    mat4 model = T * R * S;                                               // Concatena transformaciones del objeto gráfico.
    vec4 worldPosition = model * vec4(aPosition, 1.0);                    // Transforma vértice local a mundo.
    vFragPos = worldPosition.xyz;                                         // Envía posición mundial.
    vNormal = normalize(mat3(transpose(inverse(model))) * aNormal);        // Transforma la normal correctamente.
    vLocalPos = aPosition;                                                // Conserva la posición local original del cubo unitario.
    vLocalNormal = aNormal;                                               // Conserva la normal local original de cada cara.
    gl_Position = uProjection * uView * worldPosition;                    // Proyecta el vértice a pantalla.
}                                                                        // Fin del vertex shader.
