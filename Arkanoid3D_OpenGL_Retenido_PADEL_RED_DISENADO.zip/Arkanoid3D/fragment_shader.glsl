#version 330 core                                                        // Versión GLSL para OpenGL 3.3 Core.

in vec3 vFragPos;                                                        // Posición mundial del fragmento.
in vec3 vNormal;                                                         // Normal mundial del fragmento.
in vec3 vLocalPos;                                                       // Posición local interpolada del fragmento dentro del cubo.
in vec3 vLocalNormal;                                                    // Normal local interpolada para identificar la cara del cubo.
out vec4 FragColor;                                                      // Color final.

uniform vec3 uLightPos;                                                  // La luz está en la esfera.
uniform vec3 uViewPos;                                                   // Posición de la cámara.
uniform vec3 uBaseColor;                                                 // Color base del objeto gráfico.
uniform vec3 uAmbientLight;                                              // Luz ambiental.
uniform vec3 uDiffuseLight;                                              // Luz difusa.
uniform vec3 uSpecularLight;                                             // Luz especular.
uniform float uShininess;                                                // Coeficiente de brillo.
uniform float uAttenuationScale;                                         // Control de atenuación por distancia.
uniform float uAlpha;                                                    // Transparencia.
uniform float uEmissive;                                                 // Emisión propia.
uniform vec3 uAccentColor;                                                // Color secundario para degradados y bordes neón.
uniform int uGradientMode;                                                // Activa degradado especial para objetos gráficos bloque.

void main() {                                                            // Inicio del fragment shader.
    vec3 n = normalize(vNormal);                                         // Normaliza la normal n.
    vec3 l = normalize(uLightPos - vFragPos);                            // Vector l desde el punto hacia la luz.
    vec3 v = normalize(uViewPos - vFragPos);                             // Vector v desde el punto hacia el observador.
    vec3 r = normalize(2.0 * max(dot(l, n), 0.0) * n - l);               // Vector reflector r = 2(l·n)n - l.
    float dist = length(uLightPos - vFragPos);                           // Distancia del fragmento a la esfera.
    float attenuation = 1.0 / max(0.18, dist * dist * uAttenuationScale); // Atenuación por distancia.
    float diff = max(dot(n, l), 0.0);                                    // Término difuso de Lambert.
    float spec = 0.0;                                                    // Inicializa especular.
    if (diff > 0.0) spec = pow(max(dot(r, v), 0.0), uShininess);          // Calcula especular de Phong.
    vec3 objectColor = uBaseColor;                                      // Inicia el color del material con el color base.
    if (uGradientMode == 1) {                                             // Revisa si el objeto gráfico usa degradado neón.
        float high = clamp(vLocalPos.y + 0.5, 0.0, 1.0);                  // Calcula intensidad vertical de abajo hacia arriba.
        float front = clamp(vLocalPos.z + 0.5, 0.0, 1.0);                 // Calcula intensidad desde el fondo hacia la cara frontal.
        vec3 darkColor = uBaseColor * 0.38;                               // Crea un tono oscuro para zonas alejadas.
        vec3 midColor = mix(uBaseColor, uAccentColor, 0.28);              // Crea tono medio combinando base y acento.
        objectColor = mix(darkColor, midColor, high);                     // Aplica degradado vertical sobre el bloque.
        objectColor = mix(objectColor, uAccentColor, front * 0.32);       // Aclara la cara frontal para dar volumen.
        vec3 face = abs(normalize(vLocalNormal));                         // Obtiene orientación dominante de la cara local.
        float edgeXY = max(smoothstep(0.40, 0.50, abs(vLocalPos.x)), smoothstep(0.40, 0.50, abs(vLocalPos.y))); // Borde para caras frontales.
        float edgeYZ = max(smoothstep(0.40, 0.50, abs(vLocalPos.y)), smoothstep(0.40, 0.50, abs(vLocalPos.z))); // Borde para caras laterales.
        float edgeXZ = max(smoothstep(0.40, 0.50, abs(vLocalPos.x)), smoothstep(0.40, 0.50, abs(vLocalPos.z))); // Borde para caras superior/inferior.
        float edge = face.z > 0.5 ? edgeXY : (face.x > 0.5 ? edgeYZ : edgeXZ); // Selecciona borde según la cara actual.
        objectColor += uAccentColor * edge * 0.28;                         // Agrega brillo de borde para que el bloque parezca biselado.
    }                                                                     // Termina cálculo de degradado.
    vec3 ambient = uAmbientLight * objectColor;                           // Componente ambiental.
    vec3 diffuse = uDiffuseLight * objectColor * diff * attenuation;       // Componente difusa atenuada.
    vec3 specular = uSpecularLight * spec * attenuation;                  // Componente especular atenuada.
    vec3 emissive = objectColor * uEmissive;                              // Componente emisiva.
    vec3 color = ambient + diffuse + specular + emissive;                 // Suma del modelo de iluminación.
    color = color / (color + vec3(1.0));                                  // Compresión tonal para evitar saturación.
    FragColor = vec4(color, uAlpha);                                     // Color final con alfa.
}                                                                        // Fin del fragment shader.
